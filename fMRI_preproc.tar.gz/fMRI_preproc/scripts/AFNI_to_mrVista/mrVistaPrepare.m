function mrVistaPrepare(masterdir,ParticipantNumber,SessionNumber, vCheck, nTRs, myTR, nPrescanTRs, frameDuration, nTRsPerSweep, scanner)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
%
% After AFNI preproc, load into mrVista structure and continue analysis
%
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% mrVistaPrepare translates the AFNI-coordinates into mrVista coordinates,
% and applies the segmentation to get tSeries instead of nifti files.
% Optionally, it spits out a nifti containing just gray matter voxels to
% visually check whether the coordinate translation has been performed
% correctly. 

if nargin < 1
    fprintf('Please provide a project directory and try again\n')
    return;
elseif nargin == 1 && ~isstring(masterdir)
    fprintf('Please provide a project directory and try again\n')
    return;
elseif nargin == 2
    Inputpar = ParticipantNumber;
    Inputses = 0;
elseif nargin >= 3
    if isempty(ParticipantNumber) || isempty(SessionNumber)
        if ~isempty(ParticipantNumber)
            Inputses = 0;
            Inputpar = ParticipantNumber;
        else
            Inputpar = 0;
            Inputses = SessionNumber;
        end
    else
        Inputpar = ParticipantNumber;
        Inputses = SessionNumber;
    end
else
    Inputpar = 0;
    Inputses = 0;
end

if ~exist('vCheck', 'var') || isempty('vCheck')
    vCheck = 0;
end
if ~exist('nTRs', 'var') || isempty('nTRs')
    fprintf('Please set the number of TRs of your experiment WITHOUT the number of prescan TRs in startfile and try again\n')
    return;
end
if ~exist('myTR', 'var') || isempty('myTR')
    fprintf('Please set the TR of your experiment in startfile and try again\n')
    return;
end
if ~exist('nPrescanTRs', 'var') || isempty('nPrescanTRs')
    fprintf('Please set the number of prescan TRs of your experiment in startfile and try again\n')
    return;
end
if ~exist('frameDuration', 'var') || isempty('frameDuration')
    fprintf('Please set the framerate of stimulus presentation in milliseconds in startfile and try again \n')
    return;
end
if ~exist('scanner', 'var') || isempty('scanner')
    fprintf('Please specify where the protocol was scanner (UMC or Spinoza) in startfile and try again \n')
    return;
end

% frameLength = 50; % Duration of one frame of stimulus presentation in ms
framesPerTR = myTR*1000/frameDuration; % 42 if TR=2.1
nFramesPerSweep = nTRsPerSweep*framesPerTR; % How many separate frames were shown during one condition
params.prescanFrames = nPrescanTRs; % MAKE INTO PARAM STRUCTURE
params.realFrames = nTRs; % MAKE INTO PARAM STRUCTURE
rmdpath = '/mnt/data/matlabNew/rmDevel';
% addpath(genpath(vistasoftpath));
addpath(genpath(rmdpath));
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Create FULL structure first.
% Based on this list, finding specific sessions is easier to implement.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% List directories to find number of participants
listing = dir(masterdir);
listing = removehidden(listing);
ll = splitstruct_ff(listing);
numPart = length(ll);
% Allocate variables: numRuns, numSes, sesNames, partNames
numRuns = [];numSes = [];partNames = [];sesNames = [];
for np = ParticipantNumber
    % Find the NAMES of the participants
    partNames{np} = listing(np).name;
    partDir = [masterdir '/' partNames{np}];
    cd(partDir)
    [plist, pfiles, ploc] = splitstruct_ff(removehidden(dir(partDir)));
    % Can use pfiles later to carry project_info stuff
    %     plist = splitstruct_ff(plist);
    numSes(np) = length(plist);
    if Inputses == 0; Inputses = 1:numSes(np); end
    for ns = Inputses
        clear params
        sesDir = [partDir '/' plist{ns}];
        try
            cd(sesDir)
        catch
            continue;
        end
        % Move to local mrVista directory to start the analysis
        projectdir = [sesDir '/mrVistaSession'];
        try
            cd(projectdir)
            % Only if there is a mrVistaSession in this directory will we add
            % it to the sesNames structure, which will contain only actual
            % scanning sessions
            sesNames{np,ns} = plist{ns};
        catch
            % Else, we will give it 'NoSession' label
            sesNames{np,ns} = 'NoSession';
            continue;
        end
        % Initialize session with the following files:
        % Inplane       <- lo2hi_for_clp_params
        % Functional    <- clp_EPI's
        % Volume        <- t1_1mm
        % First, find some files
        EPIlist = dir('clp_*.nii');
%         EPIlist = dir('clp_EPI*');
%         inplist = dir('*lo2hi_for_clp_params*'); % for YC_new in AuditoryTiming_DenseCoverage
        inplist = dir('*lo2hi_hibase_org*');
        % Remember to ask whether this flip happens automatically when the inplane is flipped, or whether I have to specify
        % the flip for all individual runs.
        vollist = dir('*1mm.nii*');
        % Create some parameters
        numRuns(np,ns) = length(EPIlist);
        for nr = 1:numRuns(np,ns)
            params.functionals{nr} = EPIlist(nr).name;
        end
        params.vAnatomy = vollist(1).name;
        params.inplane = inplist(1).name;
        % Initialize session:
        mrInit(params);
        % Creates: mrSESSION.mat, mrInit_params.mat
        %% Adjust the mrSESSION file such that mrVista understands the proper alignment
        load mrSESSION.mat
        % Make the flip easier to handle:
        % Load in the low-res_T1
        local = readFileNifti(mrSESSION.inplanes.inplanePath);
        %         hires = readFileNifti(params.vAnatomy);
        hires = readFileNifti('t1_1mm.nii');
        % Redefine the alignment parameters based on the size of the R-L dimension
        % Add +1 to the dimension to be flipped, as space starts counting from zero, but indices start at one!
        load('clp_params.mat')
        
        %         UMC = 'MATRIX(-1,0,0,84,0,-1,0,121,0,0,1,-47):168,199,136';
        %         UMC2 = 'MATRIX(-1,0,0,83,0,-1,0,121,0,0,1,-46):167,195,133';
        %         Spinoza = 'MATRIX(1,0,0,5,0,1,0,53,0,0,1,87):158,158,120';
        
        % Minus signs matter
        % But what does this info rely on?
        if strcmp(scanner,'UMC')
            mrSESSION.alignment = [-0 -0 -1 local.dim(3)+clp_n(6)+1; 1 -0 0 clp_n(3); 0 1 -0 clp_n(1); 0 0 0 1]; % For everything related to our lab
        elseif strcmp(scanner,'Spinoza')
            mrSESSION.alignment = [-0 -0 -1 local.dim(3)+1; 1 0 0 0; 0 1 -0 0; 0 0 0 1]; % For Yuxuan
%             mrSESSION.alignment = [-0 -0 -1 0; 1 -0 0 0; 0 1 -0 0; 0 0 0 1]; % For Yuxuan
%             mrSESSION.alignment = [-0 -0 -1 local.dim(3)+clp_n(6)+1; 1 -0 0 clp_n(3); 0 1 -0 clp_n(2); 0 0 0 1]; % For Yuxuan
        elseif strcmp(scanner, 'SpinozaFullBrain')
            mrSESSION.alignment = [-0 -0 -1 local.dim(3)+clp_n(6)+1; 1 -0 0 clp_n(4); 0 1 -0 clp_n(1); 0 0 0 1]; % For Serge + Ben + Jacob + Martijn scanned at spinoza
        end
        if ~exist('vANATOMYPATH','var') || isempty(vANATOMYPATH)
            vANATOMYPATH = [projectdir '/' params.vAnatomy];
        end
        save('mrSESSION.mat', 'mrSESSION', 'dataTYPES', 'vANATOMYPATH')
        rxAlign; % Check visually
        
        % Build the actual Gray Matter coordinates using the class files:
        % Inputs are:
        % 1. Gray or volume view, default is [] for automatic hidden volume view
        % 2. Path to which to save the coords.mat file
        % 3. Flag 1== keep ALL gm-coords, 0== ONLY gm in inplane
        % 4. Segmentation file (Class file)
        % 5. Number of layers to include (in mm, hence 4 == max)
        
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        % Check if the above step can be automated entirely.
        % Which is the case if the coords structure can be reconstructed based on
        % nothing but the input niftis and the segmentation masks provided.
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        close all
        % If no input is provided, pop-up asks for class file:
        seglist = dir('*class*.nii*');
        if isempty(seglist);
            seglist = dir('*labeled*.nii*');
        end
        buildGrayCoords([],[],1,seglist.name,4);
        % Creates [nodes, edges], where node is gm voxel, and edge is number of
        % neighbors it has.
        % Necessary information is coords (DimensionsxNumberOfGrayMatterVoxels)
        % e.g. coords = [1:3, 1:400000];
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        % Get timeseries from the gm-voxels
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        close all
        VOLUME{1} = mrVista('3');
        
        inplane=checkSelectedInplane;
        VOLUME{1}=ip2volTSeries(inplane,VOLUME{1},0,'nearest'); %nearest for stats verification
        clear inplane;
        close all
        % Gives path Gray/Original/TSeries/Scan1
        % Carries: tSeries.mat
        % NumberOfTimePoints x NumberOfGrayMatterVoxels
        % e.g. tSeries = [1:196, 1:400000];
        % For later refining of the tseries, (removing empty ones)
        graypath = [projectdir '/Gray'];
        tspath = [graypath '/Original/TSeries'];
        % Construct a list of indices to keep
        for nr = 1:numRuns(np,ns)
            load([graypath '/coords.mat'])
            % Select current scan
            rundir = [tspath '/Scan' num2str(nr)];
            % Load the voxel_timeseries
            load([rundir '/tSeries1.mat'])
            % Find voxels for which the following is true:
            inds2{ns,nr}.c = find(floor((~isnan(sum(tSeries,1)) + (sum(tSeries,1)~=0))/2));
            % Make one list, but keep the originals as well
        end
        cd(partDir)
    end
    save([partDir '/ppInfo.mat'], 'sesNames');
%     save([partDir '/' sesNames{np,Inputses(1)} '/mrVistaSession/indices_for_check.mat'], 'inds2')
    % Now that we have done all sessions/runs for THIS participant:
    % construct full list of indices that we would like to keep:
    for ns = Inputses
        clear fullind
        for nr = 1:numRuns(np,ns)
            if nr == 1
                fullind = inds2{ns,nr}.c;
            else
                fullind = fullind(ismember(fullind, inds2{ns,nr}.c));
            end
        end
        % Save the coordinates we will use for analysis
        save([partDir '/' sesNames{np,ns} '/mrVistaSession/fullind.mat'], 'fullind')
    end
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % And refer back to each individual sessions' coords to update them
    % with the information we have just been given.
    for ns = Inputses
        sesDir = [partDir '/' sesNames{np,ns}];
        cd([sesDir '/mrVistaSession'])
        load([sesDir '/mrVistaSession/Gray/coords.mat']);
        load([sesDir '/mrVistaSession/fullind.mat']);
        % Use the inherent sorting of coords structure:
        coords = coords(:,fullind);
        [nodes,edges,nNotReached] = keepNodes(nodes,edges,fullind);
        % Also split into left and right
        keepLeft = keepLeft(ismember(keepLeft,fullind));
        keepRight = keepRight(ismember(keepRight,fullind));
        [allLeftNodes,allLeftEdges,nLeftNotReached] = keepNodes(allLeftNodes,allLeftEdges,keepLeft);
        [allRightNodes, allRightEdges, nRightNotReached] = keepNodes(allRightNodes, allRightEdges, keepRight);
        % And save the new coordinates (which are shared by all sessions)
        save([sesDir '/mrVistaSession/Gray/coords.mat'],'coords','nodes','edges',...
            'allLeftNodes','allLeftEdges','allRightNodes','allRightEdges',...
            'leftPath','rightPath','keepLeft','keepRight', 'leftClassFile', 'rightClassFile');
        
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        % And remake the tSeries
        close all
        [VOLUME{1}, s] = mrVista('gray');
        inplane=checkSelectedInplane;
        VOLUME{1}=ip2volTSeries(inplane,VOLUME{1},0,'nearest'); % Works
        clear inplane;
    end
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % If vCheck is set to one, will create full nifti files with only the
    % gray matter coordinates kept. Useful as a sanity check.
    if vCheck == 1
        % Run over timeseries:
        for ns = Inputses
            % Load the updated coordinate structure:
            sesDir = [partDir '/' sesNames{np,ns}];
            cd([sesDir '/mrVistaSession'])
            load([sesDir '/mrVistaSession/Gray/coords.mat']);
            load([sesDir '/mrVistaSession/clp_params.mat']);
            load([sesDir '/mrVistaSession/mrInit_params.mat']);
            for nr = 1% just one functional is enough
                % Load the updated coordinate structure:
                %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                % Return a nifti with only the gm coordinates, all else == 0
                %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                if nr == 1
                    %t1 = readFileNifti(params.vAnatomy);
                    t1 = load_nifti(params.vAnatomy);
                    % Rotate the t1 such that the coords gained from grow_gray match up:
                    p1 = [3 2 1];
                    pe = [3 2 1 4];
                    t1.vol = permute(t1.vol,p1);
                    t1.vol = flip(t1.vol,1);
                    t1.vol = flip(t1.vol,2);
                    
                    % Correct the dimensions in the nifti file
                    t = t1.dim(4);
                    t1.dim(4) = t1.dim(2);
                    t1.dim(2) = t;
                    t1.sform(:,4) = t1.sform(pe,4);
                    
                    % Extract the coordinates
                    inds = sub2ind(size(t1.vol), coords(1,:),coords(2,:),coords(3,:));
                    tmp = zeros(size(t1.vol));
                    tmp(inds) = t1.vol(inds);
                    t1.vol = tmp;
                    
                    % Invert the applied transformations
                    t1.vol = flip(t1.vol,2);
                    t1.vol = flip(t1.vol,1);
                    t1.vol = permute(t1.vol,p1);
                    
                    % Correct the dimensions in the nifti file
                    t = t1.dim(4);
                    t1.dim(4) = t1.dim(2);
                    t1.dim(2) = t;
                    t1.sform(:,4) = t1.sform(pe,4);
                    t1.fname = 'GM_only_t1.nii';
                    save_nifti(t1, 'GM_only_t1.nii');
                    
                    
                end
                
                
                % Same stuff for the epi as sanity checksum
                % Rewrite in terms of readFileNifti so we can adjust the offsets as well
%                 epi = readFileNifti(params.functionals{nr});
%                 epi.data = permute(epi.data,pe);
                
                epi = load_nifti(params.functionals{nr});
                epi.vol = permute(epi.vol,pe);
                % Correct the dimensions in the nifti file
%                 t = epi.dim(3);
%                 epi.dim(3) = epi.dim(1);
%                 epi.dim(1) = t;
%                 epi.data = flip(epi.data,1);
%                 epi.data = flip(epi.data,2);
%                 epi.sto_xyz(:,4) = epi.sto_xyz(pe,4);
                
                
                
                t = epi.dim(4);
                epi.dim(4) = epi.dim(2);
                epi.dim(2) = t;
                epi.vol = flip(epi.vol,1);
                epi.vol = flip(epi.vol,2);
                epi.sform(:,4) = epi.sform(pe,4);
                %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                % Correct for difference in box size using parameters from clp_params.mat
                % numbers represent: [R L A P I S]
                % t1.data = (lr,ap,ud) Dimensions of original
                % t1.rotdata = (ud,ap,lr); % Dimensions of rotated
                lr = clp_n(1)+clp_n(2)+1; % Number of dimensions clipped
                ap = clp_n(3)+clp_n(4); % Number of voxels clipped
%                 is = t1.dim(3)+t1.qoffset_z-clp_n(5)-clp_n(6); % Same, but from 'the other side'
                is = t1.dim(4)+t1.quatern_z-clp_n(5)-clp_n(6); % Same, but from 'the other side'

                %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                 epi.sto_xyz(1,4) = epi.sto_xyz(1,4)-is;
%                 epi.sto_xyz(2,4) = epi.sto_xyz(2,4)+ap;
%                 epi.sto_xyz(3,4) = epi.sto_xyz(3,4)+lr;
                
                % This will probably fuck us over, as read_nifti and
                % readFileNifti use different indexing. Let's find out.
                epi.sform(1,4) = epi.sform(1,4)-is;
                epi.sform(2,4) = epi.sform(2,4)+ap;
                epi.sform(3,4) = epi.sform(3,4)+lr;
                % Transform the coordinates into epi-box coordinatesip2volTSeries
                clear ecoords
                ecoords(1,:) = coords(1,:)-clp_n(6); % ap 22
                ecoords(2,:) = coords(2,:)-clp_n(4); % ud 7
                ecoords(3,:) = coords(3,:)-clp_n(1); % lr 7, lr flip
%                 inds = sub2ind(size(epi.data(:,:,:,1)), ecoords(1,:),ecoords(2,:),ecoords(3,:));
%                 for ntp = 1:size(epi.data,4)
%                     tmp2 = zeros(size(epi.data(:,:,:,1)));
%                     tmp3 = epi.data(:,:,:,ntp);
%                     tmp2(inds) = tmp3(inds);
%                     epi.data(:,:,:,ntp) = tmp2;
%                 end
%                 
                inds = sub2ind(size(epi.vol(:,:,:,1)), ecoords(1,:),ecoords(2,:),ecoords(3,:));
                for ntp = 1:size(epi.vol,4)
                    tmp2 = zeros(size(epi.vol(:,:,:,1)));
                    tmp3 = epi.vol(:,:,:,ntp);
                    tmp2(inds) = tmp3(inds);
                    epi.vol(:,:,:,ntp) = tmp2;
                end
                % Invert the applied transformations
%                 epi.sto_xyz(3,4) = epi.sto_xyz(3,4)-lr;
%                 epi.sto_xyz(2,4) = epi.sto_xyz(2,4)-ap;
%                 epi.sto_xyz(1,4) = epi.sto_xyz(1,4)+is;
%                 epi.sto_xyz(:,4) = epi.sto_xyz(pe,4);
%                 epi.data = flip(epi.data,2);
%                 epi.data = flip(epi.data,1);
%                 epi.data = permute(epi.data,pe);
%                 
                epi.sform(3,4) = epi.sform(3,4)-lr;
                epi.sform(2,4) = epi.sform(2,4)-ap;
                epi.sform(1,4) = epi.sform(1,4)+is;
                epi.sform(:,4) = epi.sform(pe,4);
                epi.vol = flip(epi.vol,2);
                epi.vol = flip(epi.vol,1);
                epi.vol = permute(epi.vol,pe);
                
                % Correct the dimensions in the nifti file
%                 t = epi.dim(3);
%                 epi.dim(3) = epi.dim(1);
%                 epi.dim(1) = t;
%                 epi.fname = ['GM_only_' params.functionals{nr}];
%                 writeFileNifti(epi);
%                 
%                 
                t = epi.dim(4);
                epi.dim(4) = epi.dim(2);
                epi.dim(2) = t;
%                 epi.fname = ['GM_only_' params.functionals{nr}];
                save_nifti(epi, 'GM_only_EPI.nii')
                
%                 save_nifti(epi, ['GM_only_' params.functionals{nr}]);
            end
        end
    else
        % Do nothing
    end
    cd(masterdir)
end
% We can clip prior to combining all the individual files
% See mrVistaClip && mrVistaCombine for the rest of the functions.

% Close any mrVista instances to avoid confusing poor matlab
close all
end