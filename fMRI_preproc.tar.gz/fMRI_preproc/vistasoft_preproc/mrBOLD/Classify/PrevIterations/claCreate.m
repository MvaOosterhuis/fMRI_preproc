function cla = claCreate
%
%
%
%
%
%



return


% We will  want to write scripts that do things like:

%  cla  = claCreate;
%  data = claData;
%  cla  = claSet(cla,'data',data);
%
%  svm = svmCreate;
%  results = claClassify(cla,svm)
%  svm = svmSet(svm,'parameters');
%
%  data = claGet(cla,'data');
%  allData = claGet(cla,'allData')
%
%  ts = claGet(cla,'data',1);
%  T = claGet(cla,'timeSteps','sec');
%  plot(T,ts)
%

% svmCreate, svmSet, svmGet
% doc class

