% Alias for mrLoadRet
disp('Clearing old mrSESSION globals');
if(exist('vANATOMYPATH','var'))
    clear vANATOMYPATH
end
if(exist('mrSESSION','var'))
    clear mrSESSION
end
if(exist('dataTYPES','var'))
    clear dataTYPES;
end
if(exist('dataTYPES','var'))
    clear dataTYPES;
end

mrVista