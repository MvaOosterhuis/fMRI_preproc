% Packs an object of any complexity (structure, cell array ect.)
% into a serialized form.
%
% mex-function, written by Dima Mihaylov (dmih@in-solve.ru)
% 
% See also DESERIALIZE