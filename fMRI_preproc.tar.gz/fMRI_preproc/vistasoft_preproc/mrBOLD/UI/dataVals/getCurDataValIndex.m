function dataValIndex = getCurDataValIndex(view)%%    curScan = getCurDataValIndex(view)if checkfields(view,'dataValIndex')    dataValIndex = view.dataValIndex;end
return;
