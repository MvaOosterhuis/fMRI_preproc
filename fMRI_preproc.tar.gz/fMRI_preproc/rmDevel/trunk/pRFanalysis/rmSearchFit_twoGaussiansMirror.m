function model = rmSearchFit_twoGaussiansMirror(model,data,params,wProcess,t,mirror)
% rmSearchFit_twoGaussiansMirror - wrapper for 'fine' one Gaussian fit
%
% model = rmSearchFit_twoGaussiansMirror(model,prediction,data,params,mirror);
%
% 2008/01 SOD: split of from rmSearchFit.

% now get original sigmas:
gridSigmas_unique = double(unique(params.analysis.sigmaMajor));
% add upper and lower limit:
expandRange    = double(params.analysis.fmins.expandRange);
gridSigmas = double([0.001.*ones(expandRange,1); ...
    gridSigmas_unique; ...
    params.analysis.sigmaRatioMaxVal.*ones(expandRange,1)]);

% fminsearch options
searchOptions         = params.analysis.fmins.options;
vethresh              = params.analysis.fmins.vethresh;

% amount of negative fits
nNegFit  = 0;
trends   = t.trends;
t_id     = t.dcid+1;

% convert to double just in case
params.analysis.X = double(params.analysis.X);
params.analysis.Y = double(params.analysis.Y);
params.analysis.allstimimages = double(params.analysis.allstimimages);
data = double(data);

%-----------------------------------
% Go for each voxel
%-----------------------------------
progress = 0;tic;
for ii = 1:numel(wProcess),

    % progress monitor (10 dots)
    if floor(ii./numel(wProcess)*10)>progress,
        % print out estimated time left
        if progress==0,
            esttime = toc.*10;
            if floor(esttime./3600)>0,
                fprintf(1,'[%s]:Estimated processing time: %d voxels: %d hours.\n',...
                    mfilename,numel(wProcess),ceil(esttime./3600));
            else
                fprintf(1,'[%s]:Estimated processing time: %d voxels: %d minutes.\n',...
                    mfilename,numel(wProcess),ceil(esttime./60));
            end;
            fprintf(1,'[%s]:Nonlinear optimization (x,y,sigma):',mfilename);
        end;
        fprintf(1,'.');drawnow;
        progress = progress + 1;
    end;

    % volume index
    vi = wProcess(ii);
    vData = data(:,ii);

    % raw rss value (non-squared) - faster than sum(data(:,vi).^2)
    rawrss     = norm(vData);
    
    % reset tolFun: Precision of evaluation function. We define RMS
    % improvement relative to the initial raw 'no-fit' data RMS. So, 1
    % means stop if there is less than 1% improvement on the fit:
    searchOptions.TolFun = params.analysis.fmins.options.TolFun.*rawrss;
    
    % start point from grid fit
    startParams = double([model.x0(vi); model.y0(vi); model.s(vi)]);

    % tight search region [lowerbound upperbound]
    if params.analysis.scaleWithSigmas,
        step = params.analysis.relativeGridStep.*startParams(3);
        minstep = params.analysis.maxXY./2./params.analysis.minimumGridSampling;
        step = min(step,minstep);
        maxstep = params.analysis.maxXY./2./params.analysis.maximumGridSampling;
        step = max(step,maxstep);
    else
        step = params.analysis.maxXY./2./params.analysis.maximumGridSampling;
    end;
    boundary.xy    = startParams([1 2])*[1 1] + ones(2,1)*[-1 1].*(step.*expandRange);

    % TO DO: respect sign
    % select the predictions we need
    if mirror(1)==-1
        boundary.xy(1,:) = min(boundary.xy(1,:),0);
    else
        if mirror(2)==-1
            boundary.xy(2,:) = min(boundary.xy(2,:),0);
        end
    end
    
    % interpolated sigmas, so we'll look for the closest one.
    [tmp,tmp2] = sort(abs(gridSigmas_unique-startParams(3)));
    closestvalue       = tmp2(1)+expandRange;
    boundary.sigma     = gridSigmas(closestvalue+[-1 1].*expandRange);
    bndParams          = [boundary.xy([1 2],:);boundary.sigma(:)'];
        
    % actual fitting routine
    if searchOptions.MaxIter>0
        outParams = ...
            fmincon(@(x) rmModelSearchFit_twoGaussiansMirror(x,vData,...
            params.analysis.X,...
            params.analysis.Y,...
            params.analysis.allstimimages,trends,mirror),...
            startParams,[],[],[],[],bndParams(:,1),bndParams(:,2),...
            @(x) distanceCon(x,startParams,step.*expandRange),searchOptions);
    else
        outParams = startParams;
    end
    %[outParams bndParams(:,1) startParams bndParams(:,2)]
    
    
    % make RF, prediction and get rss,b
    denom = -2.*(outParams(3).^2);
    Xi = params.analysis.X - outParams(1);   % positive x0 moves center right
    Yi = params.analysis.Y - outParams(2);   % positive y0 moves center up
    rf = exp( (Yi.*Yi + Xi.*Xi) ./ denom );

    Xi = params.analysis.X - mirror(1).*outParams(1);   % positive x0 moves center right
    Yi = params.analysis.Y - mirror(2).*outParams(2);   % positive y0 moves center up
    rf = rf + exp( (Yi.*Yi + Xi.*Xi) ./ denom );

    X = [params.analysis.allstimimages * rf trends];
    b    = pinv(X)*vData;
    rss  = norm(vData-X*b).^2;

    % store results only if the first beta is positive, somehow fmincon
    % outputs negative fits. If the fit is negative keep old (grid) fit.
    if b(1)>0,
        model.x0(vi)   = outParams(1);
        model.y0(vi)   = outParams(2);
        model.s(vi)    = outParams(3);
        model.x02(vi)  = mirror(1).*outParams(1);
        model.y02(vi)  = mirror(2).*outParams(2);
        model.s2(vi)   = outParams(3);
        model.rss(vi)  = rss;
        model.b([1 t_id],vi)  = b;
    else
        % change the percent variance explained to be just under the
        % current vethresh. So it counts as a 'coarse'-fit but can still be
        % included in later 'fine'-fits
        model.rss(vi)  = (1-max((vethresh-0.01),0)).*model.rawrss(vi);
        nNegFit = nNegFit + 1;
    end
end

% just in case
model.s_major = model.s;
model.s_minor = model.s;

% end time monitor
et  = toc;
if floor(et/3600)>0,
    fprintf(1,'Done [%d hours].\n',ceil(et/3600));
else
    fprintf(1,'Done [%d minutes].\n',ceil(et/60));
end;
fprintf(1,'[%s]:Removed negative fits: %d (%.1f%%).\n',...
    mfilename,nNegFit,nNegFit./numel(wProcess).*100);
return;



%-----------------------------------
% make sure that the pRF can only be moved "step" away from original
% position "startParams" - for the one Gaussian model
function [C, Ceq]=distanceCon(x,startParams,step)
Ceq = [];
dist = x([1 2])-startParams([1 2]);
C = hypot(dist(1),dist(2)) - step;
return;
%-----------------------------------

