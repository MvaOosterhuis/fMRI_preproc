function amp = rmGetAmplitude(model,params)
% rmGetAmplitude - compute %BOLD signal amplitude of the model
% 
% amp = rmGetAmplitude(model,params)
%

if ~exist('model','var') || isempty(model)
    error('Need model');
end
if ~exist('params','var') || isempty(params)
    error('Need params');
end

if iscell(model), model = model{1}; end

% loop over voxels
amp = zeros(size(model.x0),'single');
switch lower(model.description)
    case '2d prf fit (x,y,sigma, positive only)'
        denom = single(-2.*(model.sigma.major.^2));
        X  = single(params.analysis.X);
        Y  = single(params.analysis.Y);
        x0 = single(model.x0);
        y0 = single(model.y0);
        b  = single(model.beta(1,:,1));
        
        ii = find(isfinite(denom) & denom~=0);
        for n=ii
            % make RF, prediction and get rss,b
            Xv = X-x0(n);
            Yv = Y-y0(n);
            rf = exp( (Yv.*Yv + Xv.*Xv) ./ denom(n) );
            tmp  = params.analysis.allstimimages*rf;
            tmp  = tmp.*b(n); 
            amp(n) = max(tmp)-min(tmp);
        end
    otherwise
        error('model not incorporated');
end
