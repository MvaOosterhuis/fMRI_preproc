function [xy,mapSize, EccPhases]=defineFovealAtlasPRF(view,WedgeScan,LR,subparts)
if ~exist('view','var')
    filename=uigetfile;
    load(filename);
    view=FLAT{1};
    clear FLAT{1};
end
if ~exist('WedgeScan','var')
    WedgeScan=2;
end
if ~exist('LR','var')
    LR=1;
end
if ~exist('subparts','var')
    subparts=3;
end
xy=[];
xyROI=[];
punkte=(subparts+1)*10; %15 would be the advanced mode

% load kidnappedFlatData;
dataImg=view.ui.image;
mapSize=size(dataImg);
dataCmap=view.ui.phMode.cmap;
phData=view.ph;

wedge=phData{WedgeScan}(:,:,LR);
RingScan=(WedgeScan==1)+1; %(is 2 if it is 1 1 otherwise, hehe brilliant.)
ring=phData{RingScan}(:,:,LR);

drawWindows(wedge,ring,xy, subparts);

EccPhases=zeros(5,subparts+1);

options.Resize='on';
options.WindowStyle='normal';

for ROICounter=1:5;
    ttltxt = sprintf('Enter %.0f pRF sizes for ROI %.0f: ',subparts+1,ROICounter);
    answer = inputdlg('Give pRF sizes to define:',ttltxt,1,{'0  1'}, options);
    EccPhases(ROICounter, :)=str2num(answer{1});
    EccPhases(ROICounter,:)
    for PointCounter=1:2*(subparts+1)
        [xi,yi,but] = ginput(1);
        xyROI=[xyROI, [xi;yi]];
        drawWindows(wedge,ring,[xy, xyROI], subparts);
    end
    
    xy=[xy, xyROI];
    xyROI=[];
    drawWindows(wedge,ring,xy, subparts);
end
    
% while size(xy,2)<punkte
%     
%     [xi,yi,but] = ginput(1);
%     if but==32
%         xy=xy(:,1:end-1);
%     else
%         xy = [xy,[xi;yi]];
%     end
%     drawWindows(wedge,ring,xy, subparts);
% end
xy=round(xy)
return

function drawWindows(wedge,ring,xy, subparts)
map=cat(3,ring,wedge);
%lets open the window
for ii=1:2
    figure (10+ii); clf; 
    imagesc(map(:,:,ii),[-0.1 pi*2]);axis equal;hold on;  
    try
        colormap([0 0 0;marksCmap(256)]);% colormap (dataCmap);
    catch
        colormap([0 0 0;hsv(256)]);% colormap (dataCmap);
    end
    set(gca,'Xlim',[1 size(wedge,2)]);
    if~isempty(xy)
        for ii=1:size(xy,2)
            h=plot(xy(1,ii),xy(2,ii),'ko');
            set(h,'MarkerFaceColor',[0 0 0]);
        end
        if size(xy,2)>=(subparts+1)*2
            h=plot(xy(1,1:2:(subparts+1)*2),xy(2,1:2:(subparts+1)*2),'k--');
            j=plot(xy(1,2:2:(subparts+1)*2),xy(2,2:2:(subparts+1)*2),'k--');
        end
        if size(xy,2)>=(subparts+1)*4
            h=plot(xy(1,(subparts+1)*2+1:2:(subparts+1)*4),xy(2,(subparts+1)*2+1:2:(subparts+1)*4),'k--');
            j=plot(xy(1,(subparts+1)*2+2:2:(subparts+1)*4),xy(2,(subparts+1)*2+2:2:(subparts+1)*4),'k--');
        end
        if size(xy,2)>=(subparts+1)*6
            h=plot(xy(1,(subparts+1)*4+1:2:(subparts+1)*6),xy(2,(subparts+1)*4+1:2:(subparts+1)*6),'k--');
            j=plot(xy(1,(subparts+1)*4+2:2:(subparts+1)*6),xy(2,(subparts+1)*4+2:2:(subparts+1)*6),'k--');
        end
        if size(xy,2)>=(subparts+1)*8
            h=plot(xy(1,(subparts+1)*6+1:2:(subparts+1)*8),xy(2,(subparts+1)*6+1:2:(subparts+1)*8),'k--');
            j=plot(xy(1,(subparts+1)*6+2:2:(subparts+1)*8),xy(2,(subparts+1)*6+2:2:(subparts+1)*8),'k--');
        end
        if size(xy,2)>=(subparts+1)*10
            h=plot(xy(1,(subparts+1)*8+1:2:(subparts+1)*10),xy(2,(subparts+1)*8+1:2:(subparts+1)*10),'k--');
            j=plot(xy(1,(subparts+1)*8+2:2:(subparts+1)*10),xy(2,(subparts+1)*8+2:2:(subparts+1)*10),'k--');
        end        
    end
end
