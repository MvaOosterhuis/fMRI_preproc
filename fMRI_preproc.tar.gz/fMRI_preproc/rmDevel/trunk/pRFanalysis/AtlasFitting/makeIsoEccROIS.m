function [view] = makeIsoEccROIS(view, ROI, binsize)

minphase=225;
maxphase=315;

minphase=(minphase/180)*pi;
maxphase=(maxphase/180)*pi;

ROIcoords=view.ROIs(ROI).coords;
ROIeccs=zeros(length(ROIcoords), 1);
ROIphases=zeros(length(ROIcoords), 1);
for ii=1:length(ROIcoords)
    ROIeccs(ii)=view.ph{2}(ROIcoords(1,ii), ROIcoords(2,ii),1);
    ROIphases(ii)=view.ph{1}(ROIcoords(1,ii), ROIcoords(2,ii),1);
end

ROIphases

minecc=min(ROIeccs);
maxecc=max(ROIeccs);

numbins=ceil((maxecc-minecc)/binsize);

ii2=0;
currentROIs=length(view.ROIs);
for ii=1:numbins
    bii = ROIeccs >=  minecc+binsize*(ii-1) & ROIeccs<minecc+binsize*ii & ROIphases>=minphase & ROIphases<=maxphase; 
    if any(bii)
        ii2=ii2+1;
        view.ROIs(currentROIs + ii2).coords=ROIcoords(:,bii);
        minstring=num2str(minecc+binsize*(ii-1));
        maxstring=num2str(minecc+binsize*ii);
        view.ROIs(currentROIs + ii2).name=['From ', minstring, ' to ', maxstring];
        view.ROIs(currentROIs + ii2).viewType= 'Flat';
        if mod(ii2, 2)==0
            view.ROIs(currentROIs + ii2).color='m';
        else
            view.ROIs(currentROIs + ii2).color='c';
        end
        view.ROIs(currentROIs + ii2).created=(date);
        view.ROIs(currentROIs + ii2).modified=char(cellstr(date));
    end
end

view.selectedROI=currentROIs+1;
% for ii=1:length(newROIs)
%     view.ROIs(currentROIs)
%     newROIs(ii)
%     newROIs(ii).name
%     %view.ROIs(currentROIs + ii)=newROIs(ii);
% end


end

