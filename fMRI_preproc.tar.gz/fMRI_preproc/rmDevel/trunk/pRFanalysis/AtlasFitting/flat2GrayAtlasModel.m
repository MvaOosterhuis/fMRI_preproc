function [grayview] = flat2GrayAtlasModel(flatview, grayview, saveModel)
%Transfers an atlas model (eg. one created by MakeAndTestAtlasFromPoints)
%into a VOLUME structure, and saves it as the x and y coordinates of a new
%retinotopic model. Requires a starting model to be loaded in the VOLUME
%structure. To start, both eccentricity and phase data must be in FLAT
%structure 'map' fields, for scans 1 and 2 respectively. This is the
%default output from MakeAndTestAtlasFromPoints. Eccentricity data can also
%be in 'map' field with phase data in 'ph' field.

%25-Mar-1010 BMH Wrote it.

if size(flatview.map, 2)==1;
    flatview.map{2}=flatview.ph{1};
end

if size(flatview.map{1}, 3)==1
    %ie if only for one hemisphere is mapped
    flatview.map{1}(:,:,2)=zeros(size(flatview.map{1}(:,:,1)));
    flatview.map{2}(:,:,2)=zeros(size(flatview.map{2}(:,:,1)));
    %fill other hemishpere data with zeros
end

grayview = flat2volMap(flatview, grayview);
grayview.ph{1}=grayview.map{2};

if exist('saveModel', 'var')
    [x0s y0s]=pol2cart(grayview.ph{1}, grayview.map{1});
    model= grayview.rm.retinotopyModels;
    params= grayview.rm.retinotopyParams;
    model{1}=rmSet(model{1}, 'x0', x0s);
    model{1}=rmSet(model{1}, 'y0', y0s);
    pathStr=rmSave(grayview,model,params)
end
return

