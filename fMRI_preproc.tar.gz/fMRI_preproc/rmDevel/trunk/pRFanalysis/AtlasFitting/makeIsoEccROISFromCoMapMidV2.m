function [view, ROImidEccs] = makeIsoEccROISFromCoMapMidV2(view, CoIndex, binsize, eccrange, LR)

%Like makeIsoEccROIS, but does not require user to define an ROI. Instead,
%ROI coordinates are taken from the coherence map produced during atlas
%fitting. THis coherence map separates the atlas into parts depending on
%which quadrant they are found in.

vd=1;% Flag to group V2d and V2v (or V3d and V3v) together for analysis.
%1=group, 0=separate


% if LR==1
%     minphase=225;
%     maxphase=315;
% else
%     minphase=225;
%     maxphase=315;
% end
% 
% minphase=(minphase/180)*pi;
% maxphase=(maxphase/180)*pi;

initialROIs=length(view.ROIs);

for i1=1:length(CoIndex)
    
    currentROIs=length(view.ROIs);
    
    if vd==1 && CoIndex(i1)>0 && CoIndex(i1)<6;
        for vdcounter=1:2
            
            if vdcounter==2
                if CoIndex(i1)==2
                    CoIndex(i1)=5;
                elseif CoIndex(i1)==5
                    CoIndex(i1)=2;
                elseif CoIndex(i1)==1
                    CoIndex(i1)=4;
                elseif CoIndex(i1)==4
                    CoIndex(i1)=1;
                end
            end
        [rows,cols]=find(view.co{1}(:,:,LR)==CoIndex(i1));
    
    ROIcoords=ones(3, length(rows));
    ROIcoords(1,:)=rows;
    ROIcoords(2,:)=cols;
    ROIcoords(3,:)=LR;
        
    ROIeccs=zeros(length(ROIcoords), 1);
    ROIphases=zeros(length(ROIcoords), 1);
    for indexc=1:length(ROIcoords)
        ROIeccs(indexc)=view.ph{2}(ROIcoords(1,indexc), ROIcoords(2,indexc),LR);
        ROIphases(indexc)=view.ph{1}(ROIcoords(1,indexc), ROIcoords(2,indexc),LR);
    end
    
    [ROIeccs, index]=sort(ROIeccs);
    ROIphases=ROIphases(index);
    ROIcoords=ROIcoords(:,index);
    
    indexa= ROIeccs>0;
    ROIeccs=ROIeccs(indexa);
    ROIphases=ROIphases(indexa);
    ROIcoords=ROIcoords(:,indexa);
    
    medphase=median(ROIphases);
    
    if medphase>pi
        for indexd=1:length(ROIphases)
            if ROIphases(indexd)<0.5*pi
                ROIphases(indexd)=ROIphases(indexd)+2*pi;
            end
        end
    elseif medphase<pi
        for indexd=1:length(ROIphases)
            if ROIphases(indexd)>1.5*pi
                ROIphases(indexd)=ROIphases(indexd)-2*pi;
            end
        end
    end    
    
    medphase=median(ROIphases);
    minphase=medphase-(0.125*pi);
    maxphase=medphase+(0.125*pi);
    
    ROIeccs=ROIeccs./(2*pi).*eccrange;
    
    Allcoords=ROIcoords;
    
    indexb = ROIphases>=minphase & ROIphases<=maxphase;
    ROIeccs=ROIeccs(indexb);
    ROIphases=ROIphases(indexb);
    ROIcoords=ROIcoords(:,indexb);
    
 
    if vdcounter==1
        ROIeccs1=ROIeccs;
        ROIphases1=ROIphases;
        ROIcoords1=ROIcoords;
        Allcoords1=Allcoords;
    else
        ROIeccs=cat(1,ROIeccs, ROIeccs1);
        ROIphases=cat(1, ROIphases, ROIphases1);
        ROIcoords=cat(2, ROIcoords, ROIcoords1);
        Allcoords=cat(2, Allcoords, Allcoords1);
        [ROIeccs, indexe]=sort(ROIeccs);
        ROIphases=ROIphases(indexe);
        ROIcoords=ROIcoords(:,indexe);
    end
    ROImidEccs(1,i1,1)=0;
    ROImidEccs(4,i1,1)=currentROIs+1;
    
    view.ROIs(currentROIs + 1).coords=Allcoords;
    view.ROIs(currentROIs + 1).name=['Coherence flag ', num2str(CoIndex(i1))];
    view.ROIs(currentROIs + 1).viewType= 'Flat';
    
    view.ROIs(currentROIs + 1).color='w';
    
    view.ROIs(currentROIs + 1).created=date;
    view.ROIs(currentROIs + 1).modified=date;
        end
    
    

    
  
    
    
    else
        [rows,cols]=find(view.co{1}(:,:,LR)==CoIndex(i1));
        
        
        ROIcoords=ones(3, length(rows));
    ROIcoords(1,:)=rows;
    ROIcoords(2,:)=cols;
    ROIcoords(3,:)=LR;
        
    ROIeccs=zeros(length(ROIcoords), 1);
    ROIphases=zeros(length(ROIcoords), 1);
    for indexc=1:length(ROIcoords)
        ROIeccs(indexc)=view.ph{2}(ROIcoords(1,indexc), ROIcoords(2,indexc),LR);
        ROIphases(indexc)=view.ph{1}(ROIcoords(1,indexc), ROIcoords(2,indexc),LR);
    end
    
    [ROIeccs, index]=sort(ROIeccs);
    ROIphases=ROIphases(index);
    ROIcoords=ROIcoords(:,index);
    
    indexa= ROIeccs>0;
    ROIeccs=ROIeccs(indexa);
    ROIphases=ROIphases(indexa);
    ROIcoords=ROIcoords(:,indexa);
    
    medphase=median(ROIphases);
    
    if vd==0 && CoIndex(i1)>0 && CoIndex(i1)<6;
        
        if medphase>pi
            for indexd=1:length(ROIphases)
                if ROIphases(indexd)<0.5*pi
                    ROIphases(indexd)=ROIphases(indexd)+2*pi;
                end
            end
        elseif medphase<pi
            for indexd=1:length(ROIphases)
                if ROIphases(indexd)>1.5*pi
                    ROIphases(indexd)=ROIphases(indexd)-2*pi;
                end
            end
        end
        
        medphase=median(ROIphases);
        minphase=medphase-(0.125*pi);
        maxphase=medphase+(0.125*pi);
        
        
    else
        if medphase>pi
            for indexd=1:length(ROIphases)
                if ROIphases(indexd)<0.5*pi
                    ROIphases(indexd)=ROIphases(indexd)+2*pi;
                end
            end
        elseif medphase<pi
            for indexd=1:length(ROIphases)
                if ROIphases(indexd)>1.5*pi
                    ROIphases(indexd)=ROIphases(indexd)-2*pi;
                end
            end
        end
        
        medphase=median(ROIphases);
        minphase=medphase-(0.25*pi);
        maxphase=medphase+(0.25*pi);
    end
    
    ROIeccs=ROIeccs./(2*pi).*eccrange;
    
    view.ROIs(currentROIs + 1).coords=ROIcoords;
    view.ROIs(currentROIs + 1).name=['Coherence flag ', num2str(CoIndex(i1))];
    view.ROIs(currentROIs + 1).viewType= 'Flat';
    
    view.ROIs(currentROIs + 1).color='w';
    
    view.ROIs(currentROIs + 1).created=date;
    view.ROIs(currentROIs + 1).modified=date;
    
    indexb = ROIphases>=minphase & ROIphases<=maxphase;
    ROIeccs=ROIeccs(indexb);
    ROIphases=ROIphases(indexb);
    ROIcoords=ROIcoords(:,indexb);
    ROImidEccs(1,i1,1)=0;
    ROImidEccs(4,i1,1)=currentROIs+1;
    
    end
    numbins=ceil(length(ROIeccs))/binsize;

    
    
    
    for ii=1:numbins
        startindex=(ii-1)*binsize+1;
        endindex=ii*binsize;
        if endindex>length(ROIeccs)
            endindex=length(ROIeccs);
        end
        view.ROIs(currentROIs + ii+1).coords=ROIcoords(:,startindex:endindex);
        ROImidEccs(1,i1,ii+1)=mean([ROIeccs(startindex), ROIeccs(endindex)]);
        ROImidEccs(4,i1,ii+1)=currentROIs+ii+1;
        minstring=num2str(ROIeccs(startindex));
        maxstring=num2str(ROIeccs(endindex));
        view.ROIs(currentROIs + ii+1).name=['From ', minstring, ' to ', maxstring];
        view.ROIs(currentROIs + ii+1).viewType= 'Flat';
        if mod(ii, 2)==0
            view.ROIs(currentROIs + ii+1).color='m';
        else
            view.ROIs(currentROIs + ii+1).color='c';
        end
        view.ROIs(currentROIs + ii+1).created=date;
        view.ROIs(currentROIs + ii+1).modified=date;
    end
end

% 
% minecc=min(ROIeccs);
% maxecc=max(ROIeccs);
%
% numbins=ceil((maxecc-minecc)/binsize);
% 
% ii2=0;
% currentROIs=length(view.ROIs);
% for ii=1:numbins
%     bii = ROIeccs>0 & ROIeccs >=  minecc+binsize*(ii-1) & ROIeccs<minecc+binsize*ii & ROIphases>=minphase & ROIphases<=maxphase; 
%     if any(bii)
%         ii2=ii2+1;
%         view.ROIs(currentROIs + ii2).coords=ROIcoords(:,bii);
%         ROImidEccs(ii2)=minecc+binsize*(ii-0.5);
%         minstring=num2str(minecc+binsize*(ii-1));
%         maxstring=num2str(minecc+binsize*ii);
%         view.ROIs(currentROIs + ii2).name=['From ', minstring, ' to ', maxstring];
%         view.ROIs(currentROIs + ii2).viewType= 'Flat';
%         if mod(ii2, 2)==0
%             view.ROIs(currentROIs + ii2).color='m';
%         else
%             view.ROIs(currentROIs + ii2).color='c';
%         end
%         view.ROIs(currentROIs + ii2).created=(date);
%         view.ROIs(currentROIs + ii2).modified=char(cellstr(date));
%     end
% end

view.selectedROI=initialROIs+1;
% for ii=1:length(newROIs)
%     view.ROIs(currentROIs)
%     newROIs(ii)
%     newROIs(ii).name
%     %view.ROIs(currentROIs + ii)=newROIs(ii);
% end


end

