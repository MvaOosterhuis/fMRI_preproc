function [mapE,mapA,mapIdent]=createFovealAtlasFromPoints(points,EccPhases,angleStart,mapSize,verbose)

% P1=[30 64]; P2=[15 64]; P3=[1 64]; P4=[30 4];  P5=[60 10]; P6=[76 20];
% P7=[76 84]; P8=[60 94]; P9=[30 100]; P10=[80 1];P11=[100 15]; P12=[100 20];
% P13=[100 84]; P14=[100 89];  P15=[80 100];
if ~exist('points','var')
    points=[85    95   105    100    90    80    80    90    100    60    50    45    45    50    60;...
            78    78    78     105    95    90    66    57    47    120   110   105    51    42    32];
end

for thisPoint=1:size(points,2)
    a=points(:,thisPoint)';
    evalStr=['P',num2str(thisPoint),'=a;'];
    eval(evalStr);
end

if ~exist('EccPhases','var')
    EccPhases=[0.2 3 5 pi/4];
end

if ~exist('angleStart','var')
    angleStart=pi/2;
end


if ~exist('mapSize','var')
    mapSize=161;
end
if ~exist('verbose','var')
    verbose=1;
end
numOfSubparts=length(EccPhases(1,:))-1

mapE=zeros(mapSize,mapSize);
mapA=zeros(mapSize,mapSize);
mapIdent=zeros(mapSize,mapSize);

%__________________________________________________________________________
%**************************************************************************
%Center!
retPhases=[EccPhases([1 2]) angleStart];

%______________________________________________
%V1
for i=1:length(EccPhases(1,:))-1
    retPhases=EccPhases(1,:);
    retPhases=[retPhases([i i+1]) angleStart];
    A=points(:, (i-1)*2+1);%[30 64];%leftTop
    B=points(:, (i-1)*2+2);%[30 64];%leftBottom
    C=points(:, (i-1)*2+4);%[70 96];%rightBottom
    D=points(:, (i-1)*2+3);;%[70 32];%rightTop
    
    cc=cat(2, A,B,C,D);
    %cc=[10     20   60   64; 10   54   60     4]
    hemifield='hemifield';
    
    [mapA,mapE,mapIdent]=insertNewCreatedAtlasPiece(mapA,mapE,mapIdent,cc,hemifield,retPhases);
end

%______________________________________________
%V2d
for i=1:length(EccPhases(2,:))-1
    retPhases=EccPhases(2,:);
    retPhases=[retPhases([i i+1]) angleStart];
    A=points(:, (i-1)*2+1+(2*length(EccPhases(1,:))));%[30 64];%leftTop
    B=points(:, (i-1)*2+2+(2*length(EccPhases(1,:))));%[30 64];%leftBottom
    C=points(:, (i-1)*2+4+(2*length(EccPhases(1,:))));%[70 96];%rightBottom
    D=points(:, (i-1)*2+3+(2*length(EccPhases(1,:))));%[70 32];%rightTop
    
    
    hemifield='lowerquarterfield';%upperquarterfield lowerquarterfield
    cc=cat(2, A,B,C,D);cc(cc<1)=1; cc(cc>mapSize(1))=mapSize(1);
    [mapA,mapE,mapIdent]=insertNewCreatedAtlasPiece(mapA,mapE,mapIdent,cc,hemifield,retPhases);
end
%______________________________________________
%V2v
for i=1:length(EccPhases(2,:))-1
    retPhases=EccPhases(2,:);
    retPhases=[retPhases([i i+1]) angleStart];
    A=points(:, (i-1)*2+1+(4*length(EccPhases(1,:))));%[30 64];%leftTop
    B=points(:, (i-1)*2+2+(4*length(EccPhases(1,:))));%[30 64];%leftBottom
    C=points(:, (i-1)*2+4+(4*length(EccPhases(1,:))));%[70 96];%rightBottom
    D=points(:, (i-1)*2+3+(4*length(EccPhases(1,:))));%[70 32];%rightTop
    
    
    hemifield='upperquarterfield';%upperquarterfield lowerquarterfield
    cc=cat(2, A,B,C,D);cc(cc<1)=1; cc(cc>mapSize(1))=mapSize(1);
    [mapA,mapE,mapIdent]=insertNewCreatedAtlasPiece(mapA,mapE,mapIdent,cc,hemifield,retPhases);
end
%______________________________________________
%V3d
for i=1:length(EccPhases(3,:))-1
    retPhases=EccPhases(3,:);
    retPhases=[retPhases([i i+1]) angleStart];
    A=points(:, (i-1)*2+1+(6*length(EccPhases(1,:))));%[30 64];%leftTop
    B=points(:, (i-1)*2+2+(6*length(EccPhases(1,:))));%[30 64];%leftBottom
    C=points(:, (i-1)*2+4+(6*length(EccPhases(1,:))));%[70 96];%rightBottom
    D=points(:, (i-1)*2+3+(6*length(EccPhases(1,:))));%[70 32];%rightTop
    
    
    hemifield='lowerquarterfield';%upperquarterfield lowerquarterfield
    cc=cat(2, A,B,C,D);cc(cc<1)=1; cc(cc>mapSize(1))=mapSize(1);
    [mapA,mapE,mapIdent]=insertNewCreatedAtlasPiece(mapA,mapE,mapIdent,cc,hemifield,retPhases);
end

%______________________________________________
%V3v
for i=1:length(EccPhases(3,:))-1
    retPhases=EccPhases(3,:);
    retPhases=[retPhases([i i+1]) angleStart];
    A=points(:, (i-1)*2+1+(8*length(EccPhases(1,:))));%[30 64];%leftTop
    B=points(:, (i-1)*2+2+(8*length(EccPhases(1,:))));%[30 64];%leftBottom
    C=points(:, (i-1)*2+4+(8*length(EccPhases(1,:))));%[70 96];%rightBottom
    D=points(:, (i-1)*2+3+(8*length(EccPhases(1,:))));%[70 32];%rightTop
    
    
    hemifield='upperquarterfield';%upperquarterfield lowerquarterfield
    cc=cat(2, A,B,C,D);cc(cc<1)=1; cc(cc>mapSize(1))=mapSize(1);
    [mapA,mapE,mapIdent]=insertNewCreatedAtlasPiece(mapA,mapE,mapIdent,cc,hemifield,retPhases);
end

%unify the ares that belong together
areas={'v1' 'v2d' 'v2v' 'v3d' 'v3v'};
for thisPart=2:numOfSubparts
    for areaNum=1:numel(areas);
        mapIdent(mapIdent==areaNum+numel(areas)*(thisPart-1))=areaNum;
    end
end
mapIdent=mapIdent-1; mapIdent(mapIdent<0)=NaN;

%fill the holes
[mapA,mapE,mapIdent]=atlasAjustHoles(mapA,mapE,mapIdent);
[mapA,mapE,mapIdent]=atlasAjustHoles(mapA,mapE,mapIdent);
[mapA,mapE,mapIdent]=atlasAjustHoles(mapA,mapE,mapIdent);

if verbose
    figure(12);clf;
    subplot(1,2,1);
    imagesc(mapA);axis equal;colormap(hsv(128));colorbar('SouthOutside');title('Angle');
    subplot(1,2,2);
    imagesc(mapE);axis equal;colormap(hsv(128));colorbar('SouthOutside');title('Ecc');
end


