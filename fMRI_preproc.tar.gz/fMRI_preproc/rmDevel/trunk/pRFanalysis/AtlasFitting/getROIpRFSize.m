function [meanSigma, meanVarExp] = getROIpRFSize(view, ROI,LR)
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here
ROIcoords=view.ROIs(ROI).coords;
for ii=1:length(ROIcoords)
    ROIsigmas(ii)=view.amp{1}(ROIcoords(1,ii), ROIcoords(2,ii),ROIcoords(3,ii));
    ROIvarexp(ii)=view.amp{2}(ROIcoords(1,ii), ROIcoords(2,ii),ROIcoords(3,ii));
end

bii=find(ROIvarexp>0.1);

s = wstat(ROIsigmas(bii), ROIvarexp(bii));
meanSigma=s.mean;

%meanSigma=mean(ROIsigmas(bii));

meanVarExp=mean(ROIvarexp(bii));

end

