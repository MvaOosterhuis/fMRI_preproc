function rmStepSizeSimulation


p.stimSize = 15; %6.25; %deg radius
p.barWidth = p.stimSize/4;%1.56; % deg
p.numSteps = 14;
p.stepSize = 2*p.stimSize/p.numSteps;%0.625; %deg
p
p.x        = single(-p.stimSize:0.02:p.stimSize)';
p.tr       = 2.5;
p.noise    = 1;

p.prfSizes = 0.01:0.02:p.stimSize;

stim = subMakeStimulus(p);

p.position = linspace(-10,10,64);
x = p.x;
rssmat = zeros(numel(p.prfSizes),numel(p.prfSizes),numel(p.position));
rssnorm = zeros(numel(p.prfSizes),numel(p.prfSizes),numel(p.position));
rssreg = zeros(numel(p.position),numel(p.prfSizes));
for ii=1:numel(p.position)
    % make pRFs
    p.x = x - p.position(ii);
    prfs = subMakePRFs(p);
    
    % make predictions
    pred = zeros(p.numSteps+30/p.tr*2,numel(p.prfSizes));
    for n=1:numel(p.prfSizes)
        % make prediction
        pred(:,n) = stim*prfs(:,n);
    end
    
    % rms difference
    allrss = sum(pred.^2);
    rssreg(ii,:) = allrss;
    for n=1:numel(p.prfSizes)
        b = pinv(pred(:,n))*pred;
        rssmat(n,:,ii)  = sum((pred - pred(:,n)*ones(size(b))).^2);
        rssnorm(n,:,ii)  = sum((pred - pred(:,n)*b).^2)./allrss;
    end
end

% rms difference .1 deg
dist = 1; %0.01 deg
ndist = 10; % up to .5 deg
rms0p1 = NaN(numel(p.prfSizes),ndist);
rms0p1std = NaN(numel(p.prfSizes),ndist);
rms0p1_n = NaN(numel(p.prfSizes),ndist);
rms0p1std_n = NaN(numel(p.prfSizes),ndist);
tmpdist = dist;
for ii=1:ndist
    for n=1:numel(p.prfSizes)
        if n<numel(p.prfSizes)-tmpdist
            rms0p1(n,ii) = mean(rssmat(n,n+tmpdist,:));
            rms0p1std(n,ii) = std(rssmat(n,n+tmpdist,:));
            
            rms0p1_n(n,ii) = mean(rssnorm(n,n+tmpdist,:));
            rms0p1std_n(n,ii) = std(rssnorm(n,n+tmpdist,:));
        end
    end
    tmpdist = tmpdist+dist;
end



% plot
rssmean = mean(rssreg);
% set max ve to 0.6 at 1.1deg
rssnoise = 0.4*max(rssmean);
%rsstot = rssmean+rssnoise;
ve = rssreg./ (rssreg+rssnoise);
vem = mean(ve);
vestd = std(ve);
figure;hold on;
plot(p.prfSizes,vem,'k-');
plot(p.prfSizes,vem+vestd,'k:');
plot(p.prfSizes,vem-vestd,'k:');
xlabel('pRF size (deg)');ylabel('Variance explained (%)');


prfmat = p.prfSizes'*ones(1,ndist);
colors = 1-linspace(0.2,1,ndist);
figure;h=plot(prfmat,rms0p1,'k-');
for n=1:numel(h),set(h(n),'color',colors(n).*[1 1 1]);end
xlabel('pRF size (deg)');ylabel('Absolute signal difference (rms/deg)');
figure;plot(prfmat,rms0p1.*prfmat,'-');
xlabel('pRF size (deg)');ylabel('Relative signal difference (rms/deg)');

mmat = mean(rssmat,3);
sc   = max(mmat(:));

figure;hold on;
h=plot(prfmat,rms0p1.*prfmat./sc,'k-');
colors = fliplr(1-linspace(0.2,1,ndist));
for n=1:numel(h),set(h(n),'color',colors(n).*[1 1 1]);end
xlabel('pRF size (deg)');ylabel('pRF size sensitivity (rms/deg)');
set(gca,'yscale','log','ygrid','on','box','on');

% max-5%
m = rms0p1.*prfmat > ones(size(rms0p1,1),1)*(max(rms0p1.*prfmat).*.9);
ii=find(mean(m,2),1,'first');
prfmin = p.prfSizes(ii),
plot([prfmin prfmin],10.^[-6 -3],'k-');
ii=find(mean(m,2),1,'last');
prfmin = p.prfSizes(ii),
plot([prfmin prfmin],10.^[-6 -3],'k-');

% half
m = rms0p1.*prfmat > ones(size(rms0p1,1),1)*(max(rms0p1.*prfmat)./2);
ii=find(mean(m,2),1,'first');
prfmin = p.prfSizes(ii),
plot([prfmin prfmin],10.^[-6 -3],'k--');
ii=find(mean(m,2),1,'last');
prfmin = p.prfSizes(ii),
plot([prfmin prfmin],10.^[-6 -3],'k--');

% axis
axis([0 10 10^-6 10^-3])       




% 
% figure;plot(prfmat,vem'*ones(1,ndist).*rms0p1.*prfmat,'-');
% xlabel('pRF size (deg)');ylabel('Relative signal difference (rms/deg)');

figure;hold on
[cs h]=contour(p.prfSizes,p.prfSizes,mmat./sc,[.1:.1:.9]);
plot([0 6],[0 6],'k-','linewidth',1.5)
axis image xy;colormap gray
set(gca,'xtick',0:6,'ytick',0:6,'box','on');



% figure(3);plot(prfmat,rms0p1std,'-');
% xlabel('pRF size (deg)');ylabel('Signal difference variance (rms/deg)');
% figure(4);plot(prfmat,rms0p1std.*prfmat,'-');
% xlabel('pRF size (deg)');ylabel('Relative signal difference variance (rms/deg)');
% figure(5);plot(prfmat,rms0p1_n,'-');
% xlabel('pRF size (deg)');ylabel('Normalized signal difference (rms/deg)');
% figure(6);plot(prfmat,rms0p1_n.*prfmat,'-');
% xlabel('pRF size (deg)');ylabel('Normalized relative signal difference (rms/deg)');
% figure(7);plot(prfmat,rms0p1std_n,'-');
% xlabel('pRF size (deg)');ylabel('Normalized signal difference variance (rms/deg)');
% figure(8);plot(prfmat,rms0p1std_n.*prfmat,'-');
% xlabel('pRF size (deg)');ylabel('Normalized relative signal difference variance (rms/deg)');


return

function g=subMakePRFs(p)
%make x
g = p.x*ones(1,numel(p.prfSizes),'single');
%divide by sd
g = g ./(ones(numel(p.x),1,'single')*p.prfSizes);
%make gaussian
g = exp(-0.5 .* g.^2);
% set volume to 1
%g = g ./ (ones(size(p.x))*sqrt(2.*pi.*p.prfSizes.^2))./100;
% sum(g) %should ==1
return


function s=subMakeStimulus(p)
s = p.x*ones(1,p.numSteps);
pos = linspace(-p.stimSize,p.stimSize,p.numSteps);
s = s - ones(numel(p.x),1)*pos;
s = abs(s);
s = single(s<p.barWidth./2);
% add blanks
b = zeros(numel(p.x),30./p.tr);
s = [b s b];
% convolve with HRF (add beginning)
s = rfConvolveTC(s',p.tr,'t');
return

